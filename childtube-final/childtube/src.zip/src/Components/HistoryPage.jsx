// Components/HistoryPage.js

import React from "react";
import { List, ListItem, Avatar, Typography, Button } from "@mui/material";
import "./HistoryPage.css";

const HistoryPage = ({ history }) => {
  return (
    <div className="history-page">
      <Typography variant="h4" className="history-title">Watch History</Typography>
      <List className="history-list">
        {history.length > 0 ? (
          history.map((video, index) => (
            <ListItem key={index} className="history-item">
              <Avatar src={video.thumbnail} alt={video.title} className="history-avatar" />
              <div className="history-info">
                <Typography variant="h6" className="history-video-title">{video.title}</Typography>
                <Typography variant="body2" className="history-channel">Channel: {video.channel}</Typography>
              </div>
              <Button variant="outlined" color="secondary" onClick={() => window.open(`https://www.youtube.com/watch?v=${video.id}`, "_blank")}>
                Watch Again
              </Button>
            </ListItem>
          ))
        ) : (
          <Typography variant="body1" className="no-history">
            No videos watched yet!
          </Typography>
        )}
      </List>
    </div>
  );
};

export default HistoryPage;
