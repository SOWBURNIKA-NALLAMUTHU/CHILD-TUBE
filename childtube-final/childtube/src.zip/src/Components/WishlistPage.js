import React from "react";
import { Grid, Avatar, IconButton, Button } from "@mui/material";
import { Delete as DeleteIcon } from "@mui/icons-material";
import "./WishlistPage.css"; // Separate CSS file for styling

const WishlistPage = ({ wishlist, handleRemoveFromWishlist }) => {
  return (
    <div className="wishlist-page">
      <h1 className="wishlist-title">Your Wishlist</h1>
      {wishlist.length === 0 ? (
        <p className="empty-message">Your wishlist is empty! Start adding videos you love!</p>
      ) : (
        <Grid container spacing={3}>
          {wishlist.map((video) => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={video.id}>
              <div className="wishlist-video-card">
                <img src={video.thumbnail} alt={video.title} className="video-img" />
                <div className="video-info">
                  <Avatar className="channel-avatar">K</Avatar>
                  <div className="video-meta">
                    <h4 className="video-title">{video.title}</h4>
                    <p className="video-channel">{video.channel}</p>
                    <p className="video-views-time">
                      {video.views} • {video.time}
                    </p>
                  </div>
                </div>
                <Button
                  variant="contained"
                  color="secondary"
                  startIcon={<DeleteIcon />}
                  onClick={() => handleRemoveFromWishlist(video.id)}
                >
                  Remove
                </Button>
              </div>
            </Grid>
          ))}
        </Grid>
      )}
    </div>
  );
};

export default WishlistPage;
