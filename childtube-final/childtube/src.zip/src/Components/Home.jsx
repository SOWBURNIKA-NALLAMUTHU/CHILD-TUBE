// import React, { useState, useEffect, useCallback } from "react";
// import { 
//   AppBar, Toolbar, IconButton, InputBase, Menu, MenuItem, Drawer, 
//   List, ListItem, Divider, Grid, Avatar, Badge, Modal, Button 
// } from "@mui/material";
// import { 
//   Menu as MenuIcon, Search as SearchIcon, Notifications as NotificationsIcon, 
//   AccountCircle, Mic as MicIcon, Close as CloseIcon, Favorite as FavoriteIcon, 
//   PlaylistAdd as PlaylistAddIcon 
// } from "@mui/icons-material";
// import { useNavigate } from "react-router-dom";
// import "./Home.css";
// import axios from "axios";

// const YOUTUBE_API_KEY = "AIzaSyD2y5lZCOzfhXfUJsyzm8kI_HGJJrdMEuQ";

// const Home = ({ handleAddToWishlist, handleAddToLiked, handleAddToHistory }) => {
//   const navigate = useNavigate();
//   const [isDrawerOpen, setDrawerOpen] = useState(false);
//   const [anchorEl, setAnchorEl] = useState(null);
//   const [selectedVideoId, setSelectedVideoId] = useState(null);
//   const [isModalOpen, setModalOpen] = useState(false);
//   const [likedVideos, setLikedVideos] = useState(new Set());
//   const [wishlistVideos, setWishlistVideos] = useState(new Set());
//   const [videoData, setVideoData] = useState([]);

//   const fetchVideos = useCallback(async (query) => {
//     try {
//       const response = await axios.get(`https://www.googleapis.com/youtube/v3/search`, {
//         params: {
//           key: YOUTUBE_API_KEY,
//           q: query,
//           type: "video",
//           part: "snippet",
//           maxResults: 30,
//         },
//       });
//       const fetchedVideos = response.data.items.map((item) => ({
//         id: item.id.videoId,
//         title: item.snippet.title,
//         channel: item.snippet.channelTitle,
//         thumbnail: item.snippet.thumbnails.high.url,
//       }));
//       setVideoData(fetchedVideos);
//     } catch (error) {
//       console.error("Error fetching YouTube videos:", error);
//     }
//   }, []);

//   useEffect(() => {
//     fetchVideos("children rhymes and stories");
//   }, [fetchVideos]);

//   const handleProfileMenuOpen = (event) => setAnchorEl(event.currentTarget);
//   const handleMenuClose = () => setAnchorEl(null);
//   const toggleDrawer = () => setDrawerOpen(!isDrawerOpen);
//   const handleNavigateToSettings = () => { handleMenuClose(); navigate("/settings"); };
//   const handleNavigateToWishlist = () => { toggleDrawer(); navigate("/wishlist"); };
//   const handleNavigateToLiked = () => { toggleDrawer(); navigate("/liked"); };
//   const handleNavigateToReport = () => { toggleDrawer(); navigate("/report"); };
//   const handleNavigateToHelp = () => { toggleDrawer(); navigate("/help"); };
//   const handleCloseModal = () => { setModalOpen(false); setSelectedVideoId(null); };
//   const handleLogout = () => { handleMenuClose(); navigate("/"); };

//   const handleVideoClick = (videoId, video) => {
//     setSelectedVideoId(videoId);
//     setModalOpen(true);
//     handleAddToHistory(video); // Add the video to history
//   };

//   const toggleLike = (video) => {
//     setLikedVideos((prevLikedVideos) => {
//       const updatedLikedVideos = new Set(prevLikedVideos);
//       updatedLikedVideos.has(video.id) ? updatedLikedVideos.delete(video.id) : updatedLikedVideos.add(video.id);
//       handleAddToLiked(video);
//       return updatedLikedVideos;
//     });
//   };

//   const toggleWishlist = (video) => {
//     setWishlistVideos((prevWishlistVideos) => {
//       const updatedWishlistVideos = new Set(prevWishlistVideos);
//       updatedWishlistVideos.has(video.id) ? updatedWishlistVideos.delete(video.id) : updatedWishlistVideos.add(video.id);
//       handleAddToWishlist(video);
//       return updatedWishlistVideos;
//     });
//   };

//   return (
//     <div className="App">
//       <AppBar position="static" className="navbar">
//         <Toolbar>
//           <IconButton edge="start" color="inherit" onClick={toggleDrawer}>
//             <MenuIcon />
//           </IconButton>
//           <div className="logo">ChildTube</div>
//           <div className="search-container">
//             <InputBase placeholder="Search..." className="search-bar" />
//             <IconButton color="inherit">
//               <SearchIcon />
//             </IconButton>
//           </div>
//           <IconButton color="inherit"><MicIcon /></IconButton>
//           <IconButton color="inherit">
//             <Badge badgeContent={4} color="secondary"><NotificationsIcon /></Badge>
//           </IconButton>
//           <IconButton color="inherit" onClick={handleProfileMenuOpen}><AccountCircle /></IconButton>
//           <Menu anchorEl={anchorEl} keepMounted open={Boolean(anchorEl)} onClose={handleMenuClose}>
//             <MenuItem onClick={handleMenuClose}>Account</MenuItem>
//             <MenuItem onClick={handleNavigateToSettings}>Settings</MenuItem>
//             <MenuItem onClick={handleLogout}>Logout</MenuItem>
//           </Menu>
//         </Toolbar>
//       </AppBar>
//       <Drawer anchor="left" open={isDrawerOpen} onClose={toggleDrawer}>
//         <List className="sidebar">
//           <ListItem button onClick={() => navigate("/")}>Home</ListItem>
//           <Divider />
//           <ListItem button onClick={handleNavigateToWishlist}>Wishlist</ListItem>
//           <ListItem button onClick={handleNavigateToLiked}>Likes</ListItem>
//           <ListItem button onClick={() => navigate("/history")}>History</ListItem>
//           <Divider />
//           <ListItem button onClick={handleNavigateToSettings}>Settings</ListItem>
//           <ListItem button onClick={handleNavigateToReport}>Report</ListItem>
//           <ListItem button onClick={handleNavigateToHelp}>Help</ListItem>
//         </List>
//       </Drawer>
//       <div className="main-content">
//         <Grid container spacing={3}>
//           {videoData.map((video) => (
//             <Grid item xs={12} sm={6} md={4} lg={3} key={video.id}>
//               <div className="video-card" onClick={() => handleVideoClick(video.id, video)}>
//                 <img src={video.thumbnail} alt={video.title} className="video-img" />
//                 <div className="video-info">
//                   <Avatar className="channel-avatar">K</Avatar>
//                   <div className="video-meta">
//                     <h4 className="video-title">{video.title}</h4>
//                     <p className="video-channel">{video.channel}</p>
//                   </div>
//                 </div>
//                 <div className="video-actions">
//                   <Button variant={likedVideos.has(video.id) ? "contained" : "outlined"} color="primary" startIcon={<FavoriteIcon />} onClick={(e) => { e.stopPropagation(); toggleLike(video); }}>
//                     {likedVideos.has(video.id) ? "Liked" : "Like"}
//                   </Button>
//                   <Button variant={wishlistVideos.has(video.id) ? "contained" : "outlined"} color="secondary" startIcon={<PlaylistAddIcon />} onClick={(e) => { e.stopPropagation(); toggleWishlist(video); }}>
//                     {wishlistVideos.has(video.id) ? "In Wishlist" : "Wishlist"}
//                   </Button>
//                 </div>
//               </div>
//             </Grid>
//           ))}
//         </Grid>
//       </div>
//       <Modal open={isModalOpen} onClose={handleCloseModal}>
//         <div className="modal-content">
//           <IconButton className="modal-close" onClick={handleCloseModal}>
//             <CloseIcon style={{ color: "white" }} />
//           </IconButton>
//           {selectedVideoId && (
//             <iframe
//               width="100%"
//               height="500"
//               src={`https://www.youtube.com/embed/${selectedVideoId}`}
//               title="YouTube video player"
//               frameBorder="0"
//               allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
//               allowFullScreen
//             ></iframe>
//           )}
//         </div>
//       </Modal>
//     </div>
//   );
// };

// export default Home;
import React, { useState, useEffect, useCallback } from "react";
import { 
  AppBar, Toolbar, IconButton, InputBase, Menu, MenuItem, Drawer, 
  List, ListItem, Divider, Grid, Avatar, Badge, Modal, Button 
} from "@mui/material";
import { 
  Menu as MenuIcon, Search as SearchIcon, Notifications as NotificationsIcon, 
  AccountCircle, Mic as MicIcon, Close as CloseIcon, Favorite as FavoriteIcon, 
  PlaylistAdd as PlaylistAddIcon, Games as GamesIcon // Import the Games icon
} from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import "./Home.css";
import axios from "axios";

const YOUTUBE_API_KEY = "AIzaSyD2y5lZCOzfhXfUJsyzm8kI_HGJJrdMEuQ";

const Home = ({ handleAddToWishlist, handleAddToLiked, handleAddToHistory }) => {
  const navigate = useNavigate();
  const [isDrawerOpen, setDrawerOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedVideoId, setSelectedVideoId] = useState(null);
  const [isModalOpen, setModalOpen] = useState(false);
  const [likedVideos, setLikedVideos] = useState(new Set());
  const [wishlistVideos, setWishlistVideos] = useState(new Set());
  const [videoData, setVideoData] = useState([]);

  const fetchVideos = useCallback(async (query) => {
    try {
      const response = await axios.get(`https://www.googleapis.com/youtube/v3/search`, {
        params: {
          key: YOUTUBE_API_KEY,
          q: query,
          type: "video",
          part: "snippet",
          maxResults: 30,
        },
      });
      const fetchedVideos = response.data.items.map((item) => ({
        id: item.id.videoId,
        title: item.snippet.title,
        channel: item.snippet.channelTitle,
        thumbnail: item.snippet.thumbnails.high.url,
      }));
      setVideoData(fetchedVideos);
    } catch (error) {
      console.error("Error fetching YouTube videos:", error);
    }
  }, []);

  useEffect(() => {
    fetchVideos("children rhymes and stories");
  }, [fetchVideos]);

  const handleProfileMenuOpen = (event) => setAnchorEl(event.currentTarget);
  const handleMenuClose = () => setAnchorEl(null);
  const toggleDrawer = () => setDrawerOpen(!isDrawerOpen);
  const handleNavigateToSettings = () => { handleMenuClose(); navigate("/settings"); };
  const handleNavigateToWishlist = () => { toggleDrawer(); navigate("/wishlist"); };
  const handleNavigateToLiked = () => { toggleDrawer(); navigate("/liked"); };
  const handleNavigateToReport = () => { toggleDrawer(); navigate("/report"); };
  const handleNavigateToHelp = () => { toggleDrawer(); navigate("/help"); };
  const handleNavigateToGames = () => { navigate("/games"); }; // Navigate to games page
  const handleCloseModal = () => { setModalOpen(false); setSelectedVideoId(null); };
  const handleLogout = () => { handleMenuClose(); navigate("/"); };

  const handleVideoClick = (videoId, video) => {
    setSelectedVideoId(videoId);
    setModalOpen(true);
    handleAddToHistory(video); // Add the video to history
  };

  const toggleLike = (video) => {
    setLikedVideos((prevLikedVideos) => {
      const updatedLikedVideos = new Set(prevLikedVideos);
      updatedLikedVideos.has(video.id) ? updatedLikedVideos.delete(video.id) : updatedLikedVideos.add(video.id);
      handleAddToLiked(video);
      return updatedLikedVideos;
    });
  };

  const toggleWishlist = (video) => {
    setWishlistVideos((prevWishlistVideos) => {
      const updatedWishlistVideos = new Set(prevWishlistVideos);
      updatedWishlistVideos.has(video.id) ? updatedWishlistVideos.delete(video.id) : updatedWishlistVideos.add(video.id);
      handleAddToWishlist(video);
      return updatedWishlistVideos;
    });
  };

  return (
    <div className="App">
      <AppBar position="static" className="navbar">
        <Toolbar>
          <IconButton edge="start" color="inherit" onClick={toggleDrawer}>
            <MenuIcon />
          </IconButton>
          <div className="logo">ChildTube</div>
          <div className="search-container">
            <InputBase placeholder="Search..." className="search-bar" />
            <IconButton color="inherit">
              <SearchIcon />
            </IconButton>
          </div>
          <IconButton color="inherit"><MicIcon /></IconButton>
          <IconButton color="inherit" onClick={handleNavigateToGames}> {/* Add game icon */}
            <GamesIcon />
          </IconButton>
          <IconButton color="inherit">
            <Badge badgeContent={4} color="secondary"><NotificationsIcon /></Badge>
          </IconButton>
          <IconButton color="inherit" onClick={handleProfileMenuOpen}><AccountCircle /></IconButton>
          <Menu anchorEl={anchorEl} keepMounted open={Boolean(anchorEl)} onClose={handleMenuClose}>
            <MenuItem onClick={handleMenuClose}>Account</MenuItem>
            <MenuItem onClick={handleNavigateToSettings}>Settings</MenuItem>
            <MenuItem onClick={handleLogout}>Logout</MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>
      <Drawer anchor="left" open={isDrawerOpen} onClose={toggleDrawer}>
        <List className="sidebar">
          <ListItem button onClick={() => navigate("/")}>Home</ListItem>
          <Divider />
          <ListItem button onClick={handleNavigateToWishlist}>Wishlist</ListItem>
          <ListItem button onClick={handleNavigateToLiked}>Likes</ListItem>
          <ListItem button onClick={() => navigate("/history")}>History</ListItem>
          <Divider />
          <ListItem button onClick={handleNavigateToSettings}>Settings</ListItem>
          <ListItem button onClick={handleNavigateToReport}>Report</ListItem>
          <ListItem button onClick={handleNavigateToHelp}>Help</ListItem>
        </List>
      </Drawer>
      <div className="main-content">
        <Grid container spacing={3}>
          {videoData.map((video) => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={video.id}>
              <div className="video-card" onClick={() => handleVideoClick(video.id, video)}>
                <img src={video.thumbnail} alt={video.title} className="video-img" />
                <div className="video-info">
                  <Avatar className="channel-avatar">K</Avatar>
                  <div className="video-meta">
                    <h4 className="video-title">{video.title}</h4>
                    <p className="video-channel">{video.channel}</p>
                  </div>
                </div>
                <div className="video-actions">
                  <Button variant={likedVideos.has(video.id) ? "contained" : "outlined"} color="primary" startIcon={<FavoriteIcon />} onClick={(e) => { e.stopPropagation(); toggleLike(video); }}>
                    {likedVideos.has(video.id) ? "Liked" : "Like"}
                  </Button>
                  <Button variant={wishlistVideos.has(video.id) ? "contained" : "outlined"} color="secondary" startIcon={<PlaylistAddIcon />} onClick={(e) => { e.stopPropagation(); toggleWishlist(video); }}>
                    {wishlistVideos.has(video.id) ? "In Wishlist" : "Wishlist"}
                  </Button>
                </div>
              </div>
            </Grid>
          ))}
        </Grid>
      </div>
      <Modal open={isModalOpen} onClose={handleCloseModal}>
        <div className="modal-content">
          <IconButton className="modal-close" onClick={handleCloseModal}>
            <CloseIcon style={{ color: "white" }} />
          </IconButton>
          {selectedVideoId && (
            <iframe
              width="100%"
              height="500"
              src={`https://www.youtube.com/embed/${selectedVideoId}`}
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          )}
        </div>
      </Modal>
    </div>
  );
};

export default Home;
