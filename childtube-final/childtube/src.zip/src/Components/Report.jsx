import React, { useState } from "react";
import "./Report.css"; // Make sure this file exists for styling

const videoReports = [
  { title: "Twinkle Twinkle Little Star", views: 500000, likes: 450, reports: 1 },
  { title: "The Three Little Pigs", views: 750000, likes: 600, reports: 0 },
  { title: "Humpty Dumpty", views: 900, likes: 300000, reports: 2 },
  { title: "Old MacDonald Had a Farm", views: 1000000, likes: 800, reports: 1 },
  { title: "Cinderella - A Fairy Tale", views: 1500000, likes: 700, reports: 0 },
  { title: "The Very Hungry Caterpillar", views: 600000, likes: 950, reports: 1 },
  { title: "Hansel and Gretal", views:5000000 , likes: 400, reports: 0 },
  { title: "Little Red Riding Hood", views: 1600000, likes: 650, reports: 0 },
  { title: "Pinocchio", views: 900000000, likes: 500, reports: 3 },
  {
    title: "Goldilocks and The Three Bears",
    views: 800000,
    likes: 550,
    reports: 1,
  },
  { title: "The Thirsty Crow", views: 1250000, likes: 350, reports: 0 },
  { title: "Baa Baa Black Sheep", views: 2200000, likes: 480, reports: 1 },
];

function Report() {
  const [sortedVideos, setSortedVideos] = useState(videoReports);
  const [sortOrder, setSortOrder] = useState({ column: "", direction: "asc" });

  const handleSort = (column) => {
    const newDirection =
      sortOrder.column === column && sortOrder.direction === "asc"
        ? "desc"
        : "asc";

    const sortedArray = [...sortedVideos].sort((a, b) => {
      if (newDirection === "asc") {
        return a[column] - b[column];
      }
      return b[column] - a[column];
    });

    setSortedVideos(sortedArray);
    setSortOrder({ column, direction: newDirection });
  };

  return (
    <div className="report-container">
      <h2 className="report-title">Video Report</h2>
      <table className="report-table">
        <thead>
          <tr>
            <th>Video Title</th>
            <th
              onClick={() => handleSort("views")}
              style={{ cursor: "pointer" }}
            >
              Views{" "}
              {sortOrder.column === "views" &&
                (sortOrder.direction === "asc" ? "↑" : "↓")}
            </th>
            <th
              onClick={() => handleSort("likes")}
              style={{ cursor: "pointer" }}
            >
              Likes{" "}
              {sortOrder.column === "likes" &&
                (sortOrder.direction === "asc" ? "↑" : "↓")}
            </th>
            <th
              onClick={() => handleSort("reports")}
              style={{ cursor: "pointer" }}
            >
              Reports{" "}
              {sortOrder.column === "reports" &&
                (sortOrder.direction === "asc" ? "↑" : "↓")}
            </th>
          </tr>
        </thead>
        <tbody>
          {sortedVideos.map((video, index) => (
            <tr key={index}>
              <td>{video.title}</td>
              <td>{video.views}</td>
              <td>{video.likes}</td>
              <td>{video.reports}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="footer">
        <p>
          Note: Data is subject to change and may not reflect real-time
          statistics.
        </p>
      </div>
    </div>
  );
}

export default Report;