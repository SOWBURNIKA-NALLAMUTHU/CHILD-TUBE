// import React, { useState } from "react";
// import "./Games.css";

// const Games = () => {
//   // Rock-Paper-Scissors State
//   const [rpsResult, setRpsResult] = useState("");
//   const playRPS = (choice) => {
//     const options = ["Rock", "Paper", "Scissors"];
//     const computerChoice = options[Math.floor(Math.random() * options.length)];
//     if (choice === computerChoice) {
//       setRpsResult("It's a tie!");
//     } else if (
//       (choice === "Rock" && computerChoice === "Scissors") ||
//       (choice === "Scissors" && computerChoice === "Paper") ||
//       (choice === "Paper" && computerChoice === "Rock")
//     ) {
//       setRpsResult("You win!");
//     } else {
//       setRpsResult("Computer wins!");
//     }
//   };

//   // Tic-Tac-Toe State
//   const [tttBoard, setTttBoard] = useState(Array(9).fill(null));
//   const [isXNext, setIsXNext] = useState(true);
//   const handleTttClick = (index) => {
//     if (tttBoard[index] || calculateTttWinner(tttBoard)) return;
//     const newBoard = tttBoard.slice();
//     newBoard[index] = isXNext ? "X" : "O";
//     setTttBoard(newBoard);
//     setIsXNext(!isXNext);
//   };
//   const calculateTttWinner = (board) => {
//     const lines = [
//       [0, 1, 2],
//       [3, 4, 5],
//       [6, 7, 8],
//       [0, 3, 6],
//       [1, 4, 7],
//       [2, 5, 8],
//       [0, 4, 8],
//       [2, 4, 6],
//     ];
//     for (let [a, b, c] of lines) {
//       if (board[a] && board[a] === board[b] && board[a] === board[c]) {
//         return board[a];
//       }
//     }
//     return null;
//   };
//   const tttWinner = calculateTttWinner(tttBoard);

//   // Number Guessing State
//   const [guess, setGuess] = useState("");
//   const [guessMessage, setGuessMessage] = useState("");
//   const [targetNumber] = useState(Math.floor(Math.random() * 100) + 1);
//   const handleGuess = () => {
//     const userGuess = parseInt(guess, 10);
//     if (userGuess === targetNumber) {
//       setGuessMessage("Correct!");
//     } else if (userGuess < targetNumber) {
//       setGuessMessage("Too low!");
//     } else {
//       setGuessMessage("Too high!");
//     }
//   };

//   // Coin Toss State
//   const [coinResult, setCoinResult] = useState("");
//   const tossCoin = () => {
//     setCoinResult(Math.random() < 0.5 ? "Heads" : "Tails");
//   };

//   // Dice Roll State
//   const [diceResult, setDiceResult] = useState(1);
//   const rollDice = () => {
//     setDiceResult(Math.floor(Math.random() * 6) + 1);
//   };

//   return (
//     <div className="games-container">
//       <h1>Games Hub</h1>

//       {/* Rock-Paper-Scissors */}
//       <div className="RockPaperScissors">
//         <h2>Rock-Paper-Scissors</h2>
//         <button onClick={() => playRPS("Rock")}>Rock</button>
//         <button onClick={() => playRPS("Paper")}>Paper</button>
//         <button onClick={() => playRPS("Scissors")}>Scissors</button>
//         <p>{rpsResult}</p>
//       </div>

//       {/* Tic-Tac-Toe */}
//       <div className="TicTacToe">
//         <h2>Tic-Tac-Toe</h2>
//         {tttBoard.map((cell, index) => (
//           <button key={index} onClick={() => handleTttClick(index)}>
//             {cell}
//           </button>
//         ))}
//         <p>
//           {tttWinner
//             ? `Winner: ${tttWinner}`
//             : `Next Player: ${isXNext ? "X" : "O"}`}
//         </p>
//       </div>

//       {/* Number Guessing */}
//       <div className="NumberGuessing">
//         <h2>Number Guessing</h2>
//         <input
//           type="number"
//           value={guess}
//           onChange={(e) => setGuess(e.target.value)}
//           placeholder="Enter a number"
//         />
//         <button onClick={handleGuess}>Guess</button>
//         <p>{guessMessage}</p>
//       </div>

//       {/* Coin Toss */}
//       <div className="CoinToss">
//         <h2>Coin Toss</h2>
//         <button onClick={tossCoin}>Toss</button>
//         <p>{coinResult}</p>
//       </div>

//       {/* Dice Roll */}
//       <div className="DiceRoll">
//         <h2>Dice Roll</h2>
//         <button onClick={rollDice}>Roll</button>
//         <p>Result: {diceResult}</p>
//       </div>
//     </div>
//   );
// };

// export default Games;
