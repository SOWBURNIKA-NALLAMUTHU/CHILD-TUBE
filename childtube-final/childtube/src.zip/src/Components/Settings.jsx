import React, { useState } from 'react';
import "./Settings.css"; // Assuming your CSS is in this file
import { useNavigate } from "react-router-dom"; // Import useNavigate hook

function Settings() {
  const navigate = useNavigate();

  const [userInfo, setUserInfo] = useState({
    name: "Sree",
    email: "sree@gmail.com",
    password: "",
  });

  const [preferences, setPreferences] = useState({
    notifications: true,
    theme: "light",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserInfo({ ...userInfo, [name]: value });
  };

  const handlePreferencesChange = (e) => {
    const { name, value, type, checked } = e.target;
    setPreferences({
      ...preferences,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const handleSaveSettings = (e) => {
    e.preventDefault();
    // Add your save logic here
    console.log("User Info:", userInfo);
    console.log("Preferences:", preferences);
    alert("Settings saved successfully!");

    navigate("/home");
  };

  return (
    <div className="settings-container">
      <video
        className="background-video"
        src="https://cdn.pixabay.com/video/2023/07/16/171850-846103451_tiny.mp4" // Replace with your video URL
        autoPlay
        loop
        muted
      />
      <div className="content">
        <h2>Settings</h2>
        <form onSubmit={handleSaveSettings}>
          {/* User Information Section */}
          <div className="section">
            <h3>Profile Information</h3>
            <label>
              Name:
              <input
                type="text"
                name="name"
                value={userInfo.name}
                onChange={handleInputChange}
                required
              />
            </label>

            <label>
              Email:
              <input
                type="email"
                name="email"
                value={userInfo.email}
                onChange={handleInputChange}
                required
              />
            </label>

            <label>
              Password:
              <input
                type="password"
                name="password"
                value={userInfo.password}
                onChange={handleInputChange}
                required
              />
            </label>
          </div>

          {/* Preferences Section */}
          <div className="section">
            <h3>Preferences</h3>
            <label>
              Notifications:
              <input
                type="checkbox"
                name="notifications"
                checked={preferences.notifications}
                onChange={handlePreferencesChange}
              />
            </label>

            <label>
              Theme:
              <select
                name="theme"
                value={preferences.theme}
                onChange={handlePreferencesChange}
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
            </label>
          </div>

          {/* Save Button */}
          <button type="submit" className="save-button">
            Save Settings
          </button>
        </form>
      </div>
    </div>
  );
}

export default Settings;
