import React, { useState } from "react";
import "./Help.css"; // Import CSS for styling

const Help = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent default form submission
    alert(
      `Submitted:\nName: ${formData.name}\nEmail: ${formData.email}\nMessage: ${formData.message}`
    );
    // Clear the form
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <div className="help-container">
      <header className="help-header">
        <h1>Help Center</h1>
        <input
          type="text"
          className="search-bar"
          placeholder="Search for help..."
        />
      </header>

      <section className="help-categories">
        <h2>Popular Topics</h2>
        <ul className="category-list">
          <li>
            <a href="#account">Account Issues</a>
          </li>
          <li>
            <a href="#uploads">Video Uploads</a>
          </li>
          <li>
            <a href="#monetization">Monetization</a>
          </li>
        </ul>
      </section>

      <section className="contact-support">
        <h2>Contact Us</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            required
          />
          <textarea
            name="message"
            placeholder="Message"
            value={formData.message}
            onChange={handleChange}
            required
          ></textarea>
          <button type="submit">Submit</button>
        </form>
      </section>
    </div>
  );
};

export default Help;