import React from "react";
import { Grid, Avatar, IconButton, Button } from "@mui/material";
import { Delete as DeleteIcon } from "@mui/icons-material";
import "./LikedPage.css"; // Separate CSS file for styling

const LikedPage = ({ liked, handleRemoveFromLiked }) => {
  return (
    <div className="liked-page">
      <h1 className="liked-title">Liked Videos</h1>
      {liked.length === 0 ? (
        <p className="empt-message">You haven’t liked any videos yet!</p>
      ) : (
        <Grid container spacing={3}>
          {liked.map((video) => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={video.id}>
              <div className="liked-video-card">
                <img src={video.thumbnail} alt={video.title} className="video-img" />
                <div className="video-info">
                  <Avatar className="channel-avatar">K</Avatar>
                  <div className="video-meta">
                    <h4 className="video-title">{video.title}</h4>
                    <p className="video-channel">{video.channel}</p>
                    <p className="video-views-time">
                      {video.views} • {video.time}
                    </p>
                  </div>
                </div>
                <Button
                  variant="contained"
                  color="secondary"
                  startIcon={<DeleteIcon />}
                  onClick={() => handleRemoveFromLiked(video.id)}
                >
                  Remove
                </Button>
              </div>
            </Grid>
          ))}
        </Grid>
      )}
    </div>
  );
};

export default LikedPage;
