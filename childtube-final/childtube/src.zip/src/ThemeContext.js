import React, { createContext, useState, useContext } from "react";

// Create the ThemeContext
const ThemeContext = createContext();

// Custom hook to use theme context easily
export const useTheme = () => useContext(ThemeContext);

// ThemeProvider to wrap around the app
export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState("light"); // Default theme

  const toggleTheme = (newTheme) => {
    setTheme(newTheme);
    document.documentElement.setAttribute("data-theme", newTheme); // For CSS styling
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};
