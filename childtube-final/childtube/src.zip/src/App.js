import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Components/Home';
import AuthForm from './Components/AuthForm';
import Settings from './Components/Settings';
import WishlistPage from './Components/WishlistPage';
import LikedPage from './Components/LikedPage';
import Report from './Components/Report';
import Help from './Components/Help';
import HistoryPage from './Components/HistoryPage'; // Import History page
import Games from './Components/Games';
import { ThemeProvider } from "./ThemeContext";

function App() {
  const [wishlist, setWishlist] = useState([]);
  const [liked, setLiked] = useState([]);
  const [history, setHistory] = useState([]); // State to track watched history

  const handleAddToWishlist = (video) => {
    setWishlist((prevWishlist) => [...prevWishlist, video]);
  };

  const handleAddToLiked = (video) => {
    setLiked((prevLiked) => [...prevLiked, video]);
  };

  const handleAddToHistory = (video) => {
    setHistory((prevHistory) => [...prevHistory, video]);
  };

  return (
    <ThemeProvider>
      <Router>
        <Routes>
          <Route path="/" element={<AuthForm />} />
          <Route
            path="/home"
            element={
              <Home 
                handleAddToWishlist={handleAddToWishlist}
                handleAddToLiked={handleAddToLiked}
                handleAddToHistory={handleAddToHistory} // Pass down the history handler
              />
            }
          />
          <Route path="/settings" element={<Settings />} />
          <Route 
            path="/wishlist" 
            element={
              <WishlistPage 
                wishlist={wishlist}
              />
            } 
          />
          <Route 
            path="/liked" 
            element={
              <LikedPage 
                liked={liked}
              />
            } 
          />
          <Route path="/report" element={<Report />} />
          <Route path="/help" element={<Help />} />
          <Route path="/history" element={<HistoryPage history={history} />} /> {/* Route for History page */}
          <Route path="/games" element={<Games />} />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;
